<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '!a+z8 jl}q9jN;3A%^7ez~X!m/ecZ#jMgys]F~Rn]d.QTF+A|#f2sLxNCb!@A[/|' );

define( 'SECURE_AUTH_KEY',  '1hFldw_?Uqpk5|I=[rJ>ujY^4tP:MGfmD)Iw%Wl{i?U[K}6}<`t=TEGToLPU%O/*' );

define( 'LOGGED_IN_KEY',    'l*O]ytmnaH1$@8zj%/,TC}:.{n}<ZIydz`.^0(J!T+HbD1*@Zr`gMSE3iUz9LwB:' );

define( 'NONCE_KEY',        '8:c}P5d,d3brp>>MDZk23-v{Hk_t/EXNrqb0_L|~+9#W^{2WF2|%}q&d$OQ9A%fc' );

define( 'AUTH_SALT',        'S4pp5yb]z!*SFZOYXy3SN:$NI4wPa6:9?[A+:T73+BCJ}P^tLo*Wtz )kG0BWu}&' );

define( 'SECURE_AUTH_SALT', 'Qi;W9-QeP{1X U|o!5,Lg8.!jURt(Y/Tl8-FyG1-w&~W)Wbh|SOcEWZp(0cJHQJ/' );

define( 'LOGGED_IN_SALT',   '0Q.x,K{!yb:lSv:{d-(gmq<oF~1tb!*1dPUTF7u0H84P#v[mOO / @Rr*(LL6*{(' );

define( 'NONCE_SALT',       'pI[re|D+vX/4{3o$w]P@S<OP,rcoA9t#_Lq#&yd]$54geH=#K)q9+a:3nh e<eo6' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

